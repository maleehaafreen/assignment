import React from 'react';
import * as Babel from "babel-standalone";

const Preview = ({ code }) => {
  const transpileCode = () => {
    try {
      return Babel.transform(code, { presets: ["react", "es2015"] }).code;
    } catch (error) {
      return `Error: ${error.message}`;
    }
  };

  const executeCode = () => {
    const transpiledCode = transpileCode();
    try {
      return new Function(transpiledCode)();
    } catch (error) {
      return `Error: ${error.message}`;
    }
  };

  return (
    <div
      style={{ border: "1px solid #ddd", padding: "10px", minHeight: "300px" }}
      dangerouslySetInnerHTML={{ __html: executeCode() }}
    />
  );
};

export default Preview;
