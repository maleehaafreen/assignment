import React, { useState } from 'react';
import CodeEditor from './Editor';
import Preview from './Preview';

export function App() {
  const [code, setCode] = useState(`
    import React from 'react';
    const App = () => <h1>Hello React!</h1>;
    ReactDOM.render(<App />, document.getElementById('root'));
  `);

  return (
    <div className="App">
      <h1>Playcode React Editor</h1>
      <CodeEditor code={code} setCode={setCode} />
      <Preview code={code} />
    </div>
  );
}
